﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SalarySlip
{
    class Program
    {
        static void Main(string[] args)
        {
            Engineer e = new Engineer();
            Console.WriteLine("The total salary of engineer is: " + e.GetSalary());

            Analyst a = new Analyst();
            Console.WriteLine("The total salary of analyst is: " + a.GetSalary());

            Manager m = new Manager();
            Console.WriteLine("The total salary of manager is: " + m.GetSalary());

            Console.ReadLine();
        }
    }
    class Engineer: SalarySlip
    {
        public Engineer()
        {
            fuelAllowance = 100;
            medicalAllowance = 500;
        }
    }

    class Analyst : SalarySlip
    {
        public Analyst()
        {
            fuelAllowance = 150;
            medicalAllowance = 800;
        }
    }

    class Manager : SalarySlip
    {
        public Manager()
        {
            fuelAllowance = 250;
            medicalAllowance = 1000;
        }
    }
}
