﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SalarySlip
{
    class SalarySlip
    {
        private int baseSalary = 1500;
        public int fuelAllowance;
        public int medicalAllowance;

        public int GetSalary()
        {
            return (baseSalary + fuelAllowance + medicalAllowance);
        }
    }
}
